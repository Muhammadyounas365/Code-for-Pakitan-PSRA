<?php $this->load->view("components/header"); ?>

<?php $this->load->view($view); ?>

<?php $this->load->view("components/footer"); ?>
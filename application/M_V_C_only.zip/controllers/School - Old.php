<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class School extends Admin_Controller {
	
	public function __construct(){
        
        parent::__construct();
        $this->load->model("school_m");
    	}

	public function index($id = 0){
      $query = $this->db->get('schools');
      $number_of_rows = $query->num_rows();
      // pagination code is executed and dispaly pagination in view
      $this->load->library('pagination');
          $config = [
              'base_url'  =>  base_url('school/index'),
              'per_page'  =>  10,
              'total_rows' => $number_of_rows,
              'full_tag_open' =>  '<ul class="pagination pagination-sm">',
              'full_tag_close'  =>    '</ul>',
              'first_tag_open'    =>  '<li>',
              'first_tag_close'  =>   '</li>',
              'last_tag_open' =>  '<li>',
              'last_tag_close'  =>    '</li>',
              'next_tag_open' =>  '<li>',
              'next_tag_close'  =>    '</li>',
              'prev_tag_open' =>  '<li>',
              'prev_tag_close'  =>    '</li>',
              'num_tag_open'  =>  '<li>',
              'num_tag_close'  => '</li>',
              'cur_tag_open'  =>  '<li class="active"><a>',
              'cur_tag_close'  => '</a></li>'
          ];

        $this->pagination->initialize($config);
        if(empty($id)){
            $offset = $this->uri->segment(3,0);
        }else{
            $offset = $id;
        }
    $this->data['schools'] = $this->school_m->get_schools_list($config['per_page'], $offset);
    // echo "<pre />";
    // var_dump($this->data['schools']);
    // exit();
    $this->data['title'] = 'school';
		$this->data['description'] = 'info about school';
		$this->data['view'] = 'school/schools';
		$this->load->view('layout', $this->data);
	}


	public function create_form(){
    $this->data['type_of_institute'] = $this->type_of_institute(false);
    $this->data['districts'] = $this->districts(false);
    $this->data['gender_of_school'] = $this->gender_of_school(false);
    $this->data['level_of_institute'] = $this->level_of_institute(false);
    
		$this->data['title'] = 'school';
		$this->data['description'] = 'info about school';
		$this->data['view'] = 'school/create';
		$this->load->view('layout', $this->data);
	}


	public function create_process($id = null){
    
      //validation configuration
      $validation_config = array(
          array(
              'field' =>  'schoolName',
              'label' =>  'School Name',
              'rules' =>  'trim|required'
          ),
          array(
              'field' =>  'type_of_institute_id',
              'label' =>  'Type of school',
              'rules' =>  'trim|required'
          ),
          array(
              'field' =>  'district_id',
              'label' =>  'district',
              'rules' =>  'trim|required'
          ),
          array(
              'field' =>  'gender_of_school',
              'label' =>  'Education System',
              'rules' =>  'trim|required'
          )
      );
      $post_data = $this->input->post();
      // unset($posts['text_password']);
      $this->form_validation->set_rules($validation_config);
      if($this->form_validation->run() === TRUE){
          if($id == null){
            $msg = "New School has been created successfully";
            $type = "msg_success";
            $insert_id = $this->school_m->save($post_data);            
          }else{
            $type = "msg";
            $msg =  "School has been updated successfully";
            $insert_id = $this->school_m->save($post_data, $id);
          }
          
          if($insert_id){
              $this->session->set_flashdata($type, $msg);
              redirect('school');
          }else{
              $this->session->set_flashdata('msg_error', "Something's wrong, Please try later");
              redirect('school/create_form');
          }
      }else{

          if($id == null){
          $this->create_form();
          }else{
            var_dump($this->input->post());
            exit;
          $this->session->set_flashdata('msg_error', "Something's wrong, Please try again.");
          $path = "school/edit/".$id;
          redirect($path);
          }
      
      }

	}


  /**
   * edit a district
   * @param $district id integer
   */
  public function edit($id){

        $id = (int) $id;
        $this->data['type_of_institute'] = $this->type_of_institute(false);
        $this->data['districts'] = $this->districts(false);
        $this->data['gender_of_school'] = $this->gender_of_school(false);
        $this->data['level_of_institute'] = $this->level_of_institute(false);
        // var_dump($this->data['type_of_institute']);
        // exit();
        $this->data['school'] = $this->school_m->get($id);
        $this->data['title'] = 'school';
        $this->data['description'] = 'here you can edit and save the changes on fly.';
        $this->data['view'] = 'school/school_edit';
        $this->load->view('layout', $this->data);

  }

  public function delete($complain_id){
    $complain_id = (int) $complain_id;
    $where = array('complainTypeId' => $complain_id );
    $result = $this->school_m->delete($where);
    if($result){
        $this->session->set_flashdata('msg_success', "complain Type successfully deleted.");
          redirect('complain_type');
      }else{
          $this->session->set_flashdata('msg_error', "Something's wrong, Please try later");
          redirect('complain_type');
    }
  }



  // other data functions for loading prerequisite data 

  public function type_of_institute($list = true){
    $query = "SELECT `typeOfInstituteId`, `toiTitle` FROM `typeofinstitute`;";
    $list = $this->db->query($query)->result();
    if($list == true){
      return $list;
    }
    $data = "<option>Select</option>";
    foreach ($list as $item) {
      $data .= "<option value='".$item->levelofInstituteId."'>".$item->levelofInstituteTitle."</option>";
    }
    return $data;
  }

  public function districts($list = true){
    $query = "SELECT `districtId`, `districtTitle` FROM `district`";
    $list = $this->db->query($query)->result();
    if($list == true){
      return $list;
    }
        $data = "<option>Select</option>";
        foreach ($list as $item) {
          $data .= "<option value='".$item->districtId."'>".$item->districtTitle."</option>";
        }
        return $data;
  }

  public function gender_of_school($list = true){
    $query = "SELECT `genderOfSchoolId`, `genderOfSchoolTitle` FROM `genderofschool`";
    $list = $this->db->query($query)->result();
    if($list == true){
      return $list;
    }
      $data = "<option>Select</option>";
      foreach ($list as $item) {
        $data .= "<option value='".$item->genderOfSchoolId."'>".$item->genderOfSchoolTitle."</option>";
      }
      return $data;
  }

  public function level_of_institute($list = true){
    $query = "SELECT `levelofInstituteId`, `levelofInstituteTitle` FROM `levelofinstitute`";
    $list = $this->db->query($query)->result();
    if($list == true){
      return $list;
    }
      $data = "<option>Select</option>";
      foreach ($list as $item) {
        $data .= "<option value='".$item->levelofInstituteId." set_select('levelofInstituteId', '".$item->levelofInstituteId."', TRUE); ?> >".$item->levelofInstituteTitle."</option>";
      }
      return $data;

  }
	    
}
